PDF�ļ����ܵ���������
//////////////////////////////////////////////////
֧��PDF�ļ�����ֱ�ӽ��
֧��PDF�ļ�����ı����ƽ�
֧�ּ��ֽ��ܷ�ʽ
֧��PDF���µİ汾

�Ѿ������������ƽ�û�����ƣ�ĿǰΨһ�ƽ�档
���������ļ����к�����֧����Ӣ˫�

��ϵ��qinjg_2001@163.com

//////////////////////////////////////////////////
= Contents =

  Introduction
  Requirements and limitations
  Contact information
  Registration


= Introduction =

Advanced PDF Password Recovery (APDFPR) is a program to decrypt protected Adobe Acrobat PDF files, which have "user" and/or "owner" passwords set, preventing the file from opening or editing, printing, selecting text and graphics etc. With the Standard edition of the program, if only "owner" password is set, password recovery is not needed at all, but the file is being decrypted instantly (so all restrictions are being removed). Professional edition can also recover "User" password using brute-force and dictionary attacks, or instantly from the "Owner" password; also, it supports the "key search" attack to decrypt PDF files with 40-bit encryption redardless the password length, guaranteed. Enterprise edition also includes a new "rainbow attack" subsystem -- it is shipped with a DVD that contains special pre-computed hash tables that allows to decrypt most (an estimated 99.9 percent) 40-bit PDF files in just minutes instead of days.


= Requirements and limitations =

- Windows 2000, Windows XP or Windows Server 2003
- about 4 megabytes of free space on hard disk (4 gigabytes for Enterprise version)

The program can process files encrypted in mode 1 with standard encryption handler only. The documents protected with any other encryption handlers (like FileOpen, SASS_INTERNET_STDS from Standards Australia Software Services, or SoftLock's Acrobat Security Plug-Ins) cannot be decrypted.

Please also note that "key search" is not applicable to PDF 1.4/1.5/1.6 files (Acrobat 5/6/7, respectively) with 128-bit encryption.


= Contact information =

For Technical Support, please use the following form:

http://www.crackpassword.com/support/support.php 

You can also contact our Customer Service, Sales or Legal Department at:

http://www.elcomsoft.com/company.html

Our Fax numbers:

+1 866 448-2703 (US and Canada, toll-free)
+44 870 831-2983 (UK)
+49 18054820050734 (Germany)

Please write in English language only.

The latest version of APDFPR is always available from our web page at:

http://www.elcomsoft.com/apdfpr.html

Other password recovery products (for ZIP and RAR archives; Microsoft Office; Lotus Organizer, Lotus 1-2-3, Lotus WordPro, Lotus Approach; Corel Paradox, WordPerfect and QuattroPro; ACT! contact management software, Intuit Quicken and QuickBooks, Adobe Acrobat PDF, email clients, instant messengers, Windows 2000/XP/2003/Vista Encrypting File System on NTFS, Windows NT/2000/XP/2003/Vista user passwords, Windows PWL/RAS/dial-up/VPN/shares/asterisked passwords) are available at:

http://www.elcomsoft.com/prs.html


= Registration =

Unregistered (trial) version decrypts only first 10% pages (but at least one page) of the documents, and replaces all other pages with blank (empty) ones; with a brute-force attack, passwords longer than 4 characters cannot be recovered; some dictionary-attack options are disabled; "Use pre-computed hash tables" option is not available.

See "order.txt" for details on purchasing the full version.